import tkinter as tk
from tkinter import messagebox
from gui import create_gui

#fa partire il programma
create_gui()
